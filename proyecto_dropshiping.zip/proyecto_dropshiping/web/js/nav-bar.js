document.getElementById('incio-btn').onclick = function() {
    window.location.href = 'index.html';  // Cambia por la ruta correcta de tu página de inicio
};

document.getElementById('productos-btn').onclick = function() {
    window.location.href = 'productos.html';  // Cambia por la ruta correcta de productos
};

document.getElementById('redes-btn').onclick = function() {
    window.location.href = 'redes.html';  // Cambia por la ruta correcta de redes sociales
};

document.getElementById('contacto-btn').onclick = function() {
    window.location.href = 'contacto.html';  // Cambia por la ruta correcta de contacto
};